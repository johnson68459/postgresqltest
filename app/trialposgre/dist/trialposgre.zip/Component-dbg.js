sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("trialposgre.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);